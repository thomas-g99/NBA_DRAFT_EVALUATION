Thomas Gooding

Chapman ID: 2373468

Problem1: I referred to http://www.cplusplus.com/doc/tutorial/constants/
to remind myself on how to exactly use constants
